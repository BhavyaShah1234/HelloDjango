from django.shortcuts import render, redirect
from . import models


# Create your views here.
def index(request):
    return render(request, 'index.html')


def signup(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        dob = request.POST['dob']
        gender = request.POST['gender']
        query = models.Person.objects.filter(email=email)
        if len(query) == 0:
            query = models.Person(first_name=first_name,
                                  last_name=last_name,
                                  email=email,
                                  password=password,
                                  dob=dob,
                                  gender=gender)
            query.save()
            return redirect(f'/login/?first_name={first_name}&last_name={last_name}')
    return render(request, 'signup.html')


def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        query = models.Person.objects.filter(email=email, password=password)
        if len(query) > 0:
            query = models.Person.objects.get(email=email)
            query.active = True
            query.save()
            return redirect(f'/home/?email={email}')
        else:
            c = {'error_message': 'USER NOT FOUND'}
            return render(request, 'error.html', context=c)
    return render(request, 'login.html')


def home(request):
    if request.method == 'POST':
        email = request.GET.get('email')
        query = models.Person.objects.get(email=email)
        query.active = False
        query.save()
        return redirect(f'/?email={email}')
    else:
        email = request.GET.get('email')
        query = models.Person.objects.filter(email=email)
        if len(query) > 0:
            query = models.Person.objects.get(email=email)
            active = query.active
            if active:
                first_name = query.first_name
                last_name = query.last_name
                email = query.email
                password = query.password
                dob = query.dob
                gender = query.gender
                c = {'first_name': first_name,
                     'last_name': last_name,
                     'email': email,
                     'password': password,
                     'dob': dob,
                     'gender': gender}
                return render(request, 'home.html', context=c)
            else:
                return redirect(f'/login/?email={email}')
        else:
            c = {'error_message': 'USER NOT FOUND'}
            return render(request, 'error.html', context=c)
