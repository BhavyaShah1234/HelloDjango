from django.db import models


# Create your models here.
class Person(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(max_length=100, primary_key=True)
    password = models.CharField(max_length=20)
    dob = models.DateField()
    gender = models.CharField(max_length=1, choices=[('M', 'MALE'), ('F', 'FEMALE'), ('O', 'OTHER')])
    active = models.BooleanField(default=False)
